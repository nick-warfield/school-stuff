class Node:
    def __init__(self, item, left: "Node", right: "Node"):
        self.item = item
        self.left = left
        self.right = right
