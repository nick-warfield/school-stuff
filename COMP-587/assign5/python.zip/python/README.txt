USAGE:
	coverage run -m unittest NatUnitTest.py NatPropertiesTest.py

Dependencies:
	coverage (source: pip)
	unittest (source: pip)
